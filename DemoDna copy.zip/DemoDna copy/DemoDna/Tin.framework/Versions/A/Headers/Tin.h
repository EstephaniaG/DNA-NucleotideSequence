//
//  Tin.h
//  Tin
//
//  Created by Loren Olson on 1/6/17.
//  Created at the School of Arts, Media and Engineering,
//  Herberger Institute for Design and the Arts,
//  Arizona State University.
//  Copyright (c) 2017 Arizona Board of Regents on behalf of Arizona State University
//

#import <Cocoa/Cocoa.h>

//! Project version number for Tin.
FOUNDATION_EXPORT double TinVersionNumber;

//! Project version string for Tin.
FOUNDATION_EXPORT const unsigned char TinVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Tin/PublicHeader.h>


