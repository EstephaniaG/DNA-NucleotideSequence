//
//  Button.swift
//  DemoDna
//
//  Created by Stephanie Gonzalez on 3/30/17.
//  Copyright © 2017 ASU. All rights reserved.
//

import Foundation
import Tin
import Cocoa
import AVFoundation




class Nucleotied: NSObject, AVAudioPlayerDelegate {
    
    //This sets up the paremters of each object by creating variables that will later be used in the initializer to create each object
     //position
    var x: CGFloat
    var y: CGFloat
    //var x1: Double
    var width: CGFloat
    var height: CGFloat
    var letter: String
    var color: TColor
    var colorOff: TColor
    var activeColor: TColor
    var activeSound: AVAudioPlayer!
    var sound: String
    var duration: Double
    var counter: Int
    var countLimit: Int
    
    
    
    //This initilizes the paremeters for each object that will be drawn (nucleotide) when being drawn
    init(x:CGFloat, y: CGFloat, width: CGFloat, height: CGFloat, letter: String, activeColor: (TColor), activeSound:String) {
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.letter = letter
        self.activeColor = activeColor
        //self.activeSound = sound
        sound = activeSound
        colorOff = TColor(red: 135.0/255.0, green: 144.0/255.0, blue: 142.0/255, alpha: 1)
        color = colorOff
        duration = 1.0
        counter = 0
        countLimit = -1
   


    }
    
    //array of sounds
    //add array
    //each nucleotide or share it
    //make audio player nucleotide delegate
    //audio did finish playing
    //after played you add array, make sure nucleotide is delegate
    //when it finishes playing, delete audioplayer in that array
    //array
    //play, add to array- say name of array. append
    //nucleotide needs to be delegate
    //finishes playing- remove from array
    
    
//    func playSound()  {
//        if let audioPath = Bundle.main.path(forResource: sound, ofType: "wav") {
//            do {
//                let url = URL(fileURLWithPath: audioPath)
//    
//                let soundPlayer = try AVAudioPlayer(contentsOf: url)
//                soundPlayer.delegate = self
//    
//                debug("audio file loaded.")
//                
//            }
//            catch {
//                // If we get here, something went wrong trying to load the audio file.
//                debug(error.localizedDescription)
//            }
//        }
//        
//    }



       func playSound() {
        var sound: [String] = ["Keys1.wav", "Keys2.wav", "Keys3.wav", "Keys4.wav"] 
        //var tSound: AVAudioPlayer!
        
        let audioPath = Bundle.main.path(forResource: sound, ofType: "wav")
        do {
            sound = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
            activeSound.delegate = self
            Swift.print("Audio was loaded")
            
        
            
        }
        catch {
            Swift.print("Can't read audio file")
        }
      
        

    }
    

    func render() {
        if counter <= countLimit {
            let percentDone = CGFloat(counter) / CGFloat (countLimit)
            
            color.red = lerp(startValue: activeColor.red, endValue: colorOff.red, t: percentDone)
            color.green = lerp(startValue: activeColor.green, endValue: colorOff.green, t: percentDone)
            color.blue = lerp(startValue: activeColor.blue, endValue: colorOff.blue, t: percentDone)
            counter += 1
            
        }
        
        tin.lineWidth(1.0)
        color.setFillColor()
        tin.ellipse(centerX: x, centerY: y, width: width, height: height)
       
    }

    func makeActive() {
        // change color & fade color
        color = activeColor
        counter = 0
        countLimit = Int(duration * 60.0)
    
        
        // play sound
        //sound.play()
        
    }
    
}

