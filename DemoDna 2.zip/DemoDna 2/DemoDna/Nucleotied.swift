//
//  Button.swift
//  DemoDna
//
//  Created by Stephanie Gonzalez on 3/30/17.
//  Copyright © 2017 ASU. All rights reserved.
//

import Foundation
import Tin
import Cocoa
import AVFoundation




class Nucleotied {
    
    //This sets up the paremters of each object by creating variables that will later be used in the initializer to create each object
     //position
    var x: CGFloat
    var y: CGFloat
    var radius: CGFloat
    var width: CGFloat
    var height: CGFloat
    var color: TColor
    var letter: String
    var activeColor: TColor
    //var sound: AVAudioPlayer
    //var activeSound: AVAudioPlayer
    
    
    
    //This initilizes the paremeters for each object that will be drawn (nucleotide) when being drawn
    init(x:CGFloat, y: CGFloat, radius: CGFloat, width: CGFloat, height: CGFloat, letter: String, activeColor: (TColor)) {//,activeSound: AVAudioPlayer) {
        self.x = x
        self.y = y
        self.radius = radius
        self.width = width
        self.height = height
        self.letter = letter
        self.activeColor = activeColor
        //self.activeSound = activeSound
        //sound = activeSound
        color = TColor(red: 0.4, green: 0.4, blue: 0.4, alpha: 1.0)
    }
    
       func setup() {
        var audioPlayer: AVAudioPlayer!
        
        let audioPath = Bundle.main.path(forResource: "Keys1", ofType: "wav")
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
            //audioPlayer.delegate = self
            Swift.print("Audio was loaded")
        }
        catch {
            Swift.print("Can't read audio file")
        }
        

    }
    
    
    func render() {
        
        tin.lineWidth(1.0)
        color.setFillColor()
        tin.ellipse(centerX: x, centerY: y, width: width, height: height)
       
    }

    func makeActive() {
        // change color
        tin.frameCount = 10
        color = activeColor
    
        
        // play sound
        //sound.play()
        
    }
    
}

