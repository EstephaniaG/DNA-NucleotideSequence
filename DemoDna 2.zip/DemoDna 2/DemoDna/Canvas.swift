//
//  Canvas.swift
//

//better coordinate visuals to match the way sound sustains- how visuals are working
//method to let me transition colors-
//audio: timing/ delays- what if there needs to be overlapping audio how to enable overlapping audio
//.wav formatting audacity
//overlapping of timing-account for possiblities of timing-TEMPO
//SEPERATE abilility how long sounds should be and how long they will ring out
//be able to make a new instance out of AVAudioPlayer- make seperate instance
//keep AVAudio reference- Make function 
//func createPlayer(filename:String) -> AVAudioPlayer? {
//there needs to be a new sound object every single instance the character is getting called
//var sounds: [AVAudioplayers]
//sdounds.append(soundPlayer)
//nucleotide has string property that's name of audio file
//play sound method

import Cocoa
import Tin
import AVFoundation


class Canvas: TView, AVAudioPlayerDelegate{

    
    var text: NSString?
    var dnaText: String?
    var currentCharacter: String?
    var current = 0
    var numberOfCharacters = 0
    var audioPlayer: AVAudioPlayer!
    var audioPlayer1: AVAudioPlayer!
    var audioPlayer2: AVAudioPlayer!
    var audioPlayer3: AVAudioPlayer!
    var active = 1
    var turnOff = TColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    let numberOfNucleotides = 4
    let frameSteps = 60
    
  
    
    var t = Nucleotied(x: 300.0, y: 250.0, radius: 75.0, width: 150.0, height: 150.0, letter: "T", activeColor: TColor(red: 167.0/255.0, green: 255.0/255.0, blue: 144.0/255.0, alpha: 1.0))//, activeSound: )
    var t1 = Nucleotied(x: 300.0, y: 250.0, radius: 75.0, width: 150.0, height: 150.0, letter: "T", activeColor: TColor(red: 197/255.0, green: 200/255.0, blue: 208/255.0, alpha: 1))
    
    var g = Nucleotied(x: 500.0, y: 250.0, radius: 75.0, width: 150.0, height: 150.0, letter: "G", activeColor: TColor(red: 123.0/255.0, green: 225.0/255.0, blue: 216.0/255.0, alpha: 1.0))//, activeSound: audioPlayer)
    var g1 = Nucleotied(x: 500.0, y: 250.0, radius: 75.0, width: 150.0, height: 150.0, letter: "G", activeColor: TColor(red: 197.0/255.0, green: 200.0/255.0, blue: 208.0/255.0, alpha: 1.0))
    
    var c = Nucleotied(x: 900.0, y: 250.0, radius: 75.0, width: 150.0, height: 150.0, letter: "C", activeColor: TColor (red: 255.0/255.0, green: 173.0/255.0, blue: 66.0/255.0, alpha: 1.0))//, activeSound: audioPlayer)
    var c1 = Nucleotied(x: 900.0, y: 250.0, radius: 75.0, width: 150.0, height: 150.0, letter: "C", activeColor: TColor (red: 197.0/255.0, green: 200.0/255.0, blue: 208.0/255.0, alpha: 1.0))

    
    var a = Nucleotied(x: 700.0, y: 250.0, radius: 75.0, width: 150.0, height: 150.0, letter: "A", activeColor: TColor(red: 188.0/255.0, green: 156.0/255.0, blue: 255.0/255.0, alpha: 1.0))
    var a1 = Nucleotied(x: 700.0, y: 250.0, radius: 75.0, width: 150.0, height: 150.0, letter: "A", activeColor: TColor(red: 197.0/255.0, green: 200.0/255.0, blue: 208.0/255.0, alpha: 1.0))
    

       override func setup() {
        //loads the txtFile and creates a path from file to program, allowing the program to read the file sequentially
        showStats = false
        
        do {
            let filePath = Bundle.main.path(forResource: "good", ofType: "txt")
            text = try NSString(contentsOfFile: filePath!, encoding: String.Encoding.utf8.rawValue)
            numberOfCharacters = text!.length
            Swift.print(text!)
        }
        catch {
            Swift.print("There was an error reading the file.")
        }
        
        dnaText = text as String?
        for character in dnaText!.characters {
            Swift.print(character)
        }
        
//        //Loads the audio file by creating a path from audio file to program
//        //audio1
        let audioPath = Bundle.main.path(forResource: "Keys1", ofType: "wav")
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
            audioPlayer.delegate = self
            Swift.print("Audio was loaded")
                    }
        catch {
            Swift.print("Can't read audio file")
        }
        
        //audio2
        let audioPath1 = Bundle.main.path(forResource: "Keys2", ofType: "wav")
        do {
            audioPlayer1 = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath1!))
            audioPlayer1.delegate = self
            Swift.print("Audio was loaded")
        }
        catch {
            Swift.print("Can't read audio file")
        }
        
        //audio3
        let audioPath2 = Bundle.main.path(forResource: "Keys3", ofType: "wav")
        do {
            audioPlayer2 = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath2!))
            audioPlayer2.delegate = self
            Swift.print("Audio was loaded")
        }
        catch {
            Swift.print("Can't read audio file")
        }
        
        //audio4
        let audioPath3 = Bundle.main.path(forResource: "Keys4", ofType: "wav")
        do {
            audioPlayer3 = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath3!))
            audioPlayer3.delegate = self
            Swift.print("Audio was loaded")
        }
        catch {
            Swift.print("Can't read audio file")
        }
        
    }
    
    
    override func update() {
        tin.background(gray: 0.5)
        tin.setFillColor(gray: 10)
        t1.render()
        c1.render()
        g1.render()
        a1.render()

        //if/else statement that responds to the framecount that has been set up in order to play each sound according to each character
        if tin.frameCount % 80 == 0 {
            let character = dnaText![dnaText!.index(dnaText!.startIndex, offsetBy: current)]
            Swift.print(character)
           
            if character == "T" {
                t.makeActive()
                t.render()
                audioPlayer.play()
            }
    
            if character == "C" {
                c.makeActive()
                c.render()
               audioPlayer1.play()
            }
            
            if character == "G" {
                g.makeActive()
                g.render()
               audioPlayer2.play()
            }
            
            if character == "A" {
                a.makeActive()
                a.render()
                audioPlayer3.play()
            }
            
            current = (current + 1) % numberOfCharacters
            Swift.print("Audio is done playing")

        }
    }
}


