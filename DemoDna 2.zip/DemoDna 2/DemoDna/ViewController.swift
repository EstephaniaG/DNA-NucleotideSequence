//
//  ViewController.swift
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    override func viewWillAppear() {
        
        var newFrame = NSRect(x: 0.0, y: 0.0, width: 500.0, height: 500.0)
        
        
        if let visibleFrame = view.window?.screen?.visibleFrame {
            let h = visibleFrame.height - 150.0
            let newWinFrame = NSRect(x: visibleFrame.origin.x, y: visibleFrame.origin.y + visibleFrame.height - h, width: visibleFrame.width, height: h)
            view.window?.setFrame(newWinFrame, display: true)
            newFrame = NSRect(x: 0.0, y: 0.0, width: visibleFrame.width, height: h)
        }
        
        view = Canvas(frame: newFrame)
        
        
    }


}

